
import json
import re

GLYPH_DICTIONARY = {
    "✹": "start_flow",
    "⚛": "process_data",
    "⟿": "branch_flow",
    "∑": "summarize",
    "∞": "repeat_flow",
    "⌬": "interpret_output",
    "ƒ": "call_function",
    "ν": "set_variable"
}

VARIABLES = {}

def tokenize(sequence):
    pattern = r'(✹|⚛|⟿|∑|∞|⌬|ƒ|ν)(\{.*?\})?'
    tokens = re.findall(pattern, sequence)
    return tokens

def parse_sequence(sequence):
    tokens = tokenize(sequence)
    for token in tokens:
        glyph, data_block = token
        action = GLYPH_DICTIONARY.get(glyph)
        data = json.loads(data_block) if data_block else {}
        execute(action, data)

def execute(action, data):
    if action == "start_flow":
        print("[✹] → Iniciando flujo...")
    elif action == "process_data":
        print(f"[⚛] → Procesando datos: {data.get('data')}")
    elif action == "branch_flow":
        branches = data.get('branches', 1)
        print(f"[⟿] → Bifurcando flujo en {branches} rutas")
        for i in range(branches):
            print(f"  → Ejecutando rama {i+1}")
    elif action == "summarize":
        print(f"[∑] → Resumiendo usando método: {data.get('method')}")
    elif action == "repeat_flow":
        cycles = data.get('cycles', 1)
        print(f"[∞] → Ejecutando {cycles} ciclos")
        for i in range(cycles):
            print(f"  → Ciclo {i+1}")
    elif action == "interpret_output":
        print(f"[⌬] → Interpretando salida como: {data.get('output')}")
    elif action == "call_function":
        name = data.get('name')
        params = data.get('params', [])
        resolved_params = {p['name']: VARIABLES.get(p['value'], p['value']) for p in params}
        print(f"[ƒ] → Ejecutando función: {name} con parámetros {resolved_params}")
    elif action == "set_variable":
        VARIABLES[data['name']] = data['value']
        print(f"[ν] → Variable '{data['name']}' establecida como '{data['value']}'")
    else:
        print(f"Glífico desconocido: {action}")
