
import asyncio
import websockets
import json

connected_dashboards = set()

async def dashboard_server(websocket, path):
    connected_dashboards.add(websocket)
    try:
        async for message in websocket:
            pass
    except websockets.ConnectionClosed:
        connected_dashboards.remove(websocket)

async def broadcast_network_update(nodes, edges):
    if connected_dashboards:
        msg = {"type": "network_update", "nodes": list(nodes), "edges": list(edges)}
        await asyncio.wait([ws.send(json.dumps(msg)) for ws in connected_dashboards])

start_server = websockets.serve(dashboard_server, "localhost", 9000)
asyncio.get_event_loop().run_until_complete(start_server)
asyncio.get_event_loop().run_forever()
