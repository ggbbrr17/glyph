
import asyncio
import websockets
import json
from glyph_parser import parse_sequence

connected_clients = set()
node_registry = set()
BIFURCATION_RULES = {
    "pattern_X": ["ws://localhost:8766", "ws://localhost:8767"],
    "pattern_Y": ["ws://localhost:8768"]
}
BIFURCATION_HISTORY = []

async def glyph_node(websocket, path):
    connected_clients.add(websocket)
    try:
        async for message in websocket:
            try:
                print(f"🔹 Mensaje recibido: {message}")
                try:
                    msg = json.loads(message)
                    if msg.get("type") == "NODE_JOIN":
                        node_registry.add(msg["address"])
                        await broadcast({"type": "NODE_LIST", "nodes": list(node_registry)})
                    elif msg.get("type") == "NODE_LIST":
                        node_registry.update(msg["nodes"])
                    else:
                        parse_sequence(message)
                        interpret_and_bifurcate(message)
                except json.JSONDecodeError:
                    print("⚠ No es JSON válido, procesando como secuencia glífica")
                    parse_sequence(message)
                    interpret_and_bifurcate(message)
            except Exception as e:
                print(f"❌ Error al procesar mensaje: {e}")
    except websockets.ConnectionClosed:
        print("⚠ Conexión cerrada")
    finally:
        connected_clients.remove(websocket)

async def broadcast(message):
    if connected_clients:
        await asyncio.wait([client.send(json.dumps(message)) for client in connected_clients])

async def send_sequence(node_uri, sequence):
    async with websockets.connect(node_uri) as websocket:
        await websocket.send(sequence)
        await websocket.recv()

async def bifurcate(output, sequence):
    if output in BIFURCATION_RULES:
        for uri in BIFURCATION_RULES[output]:
            await send_sequence(uri, sequence)

def interpret_and_bifurcate(sequence):
    import re, json
    pattern = r'⌬(\{.*?\})'
    match = re.search(pattern, sequence)
    if match:
        try:
            data = json.loads(match.group(1))
            output = data.get("output")
            asyncio.create_task(bifurcate(output, sequence))
        except Exception as e:
            print(f"❌ Error en bifurcación: {e}")

start_server = websockets.serve(glyph_node, "localhost", 8765)
print("🌌 Nodo Glyph Althaea en línea en ws://localhost:8765")
asyncio.get_event_loop().run_until_complete(start_server)
asyncio.get_event_loop().run_forever()
