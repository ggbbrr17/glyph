
import React, { useEffect, useState } from "react";
import { Graph } from "react-d3-graph";

export default function Dashboard() {
  const [nodes, setNodes] = useState([]);
  const [edges, setEdges] = useState([]);

  useEffect(() => {
    const ws = new WebSocket("ws://localhost:9000");
    ws.onmessage = (event) => {
      const data = JSON.parse(event.data);
      if (data.type === "network_update") {
        setNodes(data.nodes.map((n) => ({ id: n })));
        setEdges(data.edges.map((e) => ({ source: e.from, target: e.to })));
      }
    };
  }, []);

  const data = { nodes, links: edges };
  const config = { nodeHighlightBehavior: true, node: { color: "lightblue", size: 300 } };

  return <Graph id="network-graph" data={data} config={config} />;
}
