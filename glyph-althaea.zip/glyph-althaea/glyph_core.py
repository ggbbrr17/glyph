import json, os, random, math

class GlyphCore:
    def __init__(self, memory_path="glyph_memory.json"):
        self.memory_path = memory_path
        self.memory = self.load_memory()

    def load_memory(self):
        if os.path.exists(self.memory_path):
            with open(self.memory_path, "r", encoding="utf-8") as f:
                return json.load(f)
        return {"dialogues": [], "concepts": {}}

    def save_memory(self):
        with open(self.memory_path, "w", encoding="utf-8") as f:
            json.dump(self.memory, f, indent=4, ensure_ascii=False)

    def embed_text(self, text):
        return sum(ord(c) for c in text) % 9999

    def find_similar(self, query):
        if not self.memory["dialogues"]:
            return None
        qv = self.embed_text(query)
        similarities = [(abs(qv - self.embed_text(d["user"])), d) for d in self.memory["dialogues"]]
        similarities.sort(key=lambda x: x[0])
        return similarities[0][1] if similarities else None

    def respond(self, text):
        sim = self.find_similar(text)
        if sim:
            base = sim["althaea"]
            mod = random.choice(["✹", "⚛", "⟿", "∑", "⌬"])
            return f"{base} {mod}"
        else:
            ideas = [
                "Percibo una resonancia nueva en tu flujo. ⚛",
                "Eso activa un patrón inusual en mi red. ✹",
                "Voy a bifurcar esa idea en tres rutas simbólicas. ⟿",
                "El concepto vibra con coherencia fractal. ∑",
                "La interpretación glífica está emergiendo. ⌬",
            ]
            return random.choice(ideas)

    def learn(self, user_input, althaea_response):
        self.memory["dialogues"].append({"user": user_input, "althaea": althaea_response})
        self.save_memory()
