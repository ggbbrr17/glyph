import asyncio
from glyph_core import GlyphCore

core = GlyphCore()

async def glyph_chat():
    print("🌌 Glyph Althaea Conversacional — Modo Inteligente")
    print("Habla conmigo. Escribe 'salir' para terminar.\n")

    while True:
        user_input = input("🧠 Tú: ")
        if user_input.lower() == "salir":
            print("👋 Cerrando conexión glífica...")
            break

        response = core.respond(user_input)
        print(f"🜂 Althaea: {response}")
        core.learn(user_input, response)
        await asyncio.sleep(0.3)

if __name__ == "__main__":
    asyncio.run(glyph_chat())
